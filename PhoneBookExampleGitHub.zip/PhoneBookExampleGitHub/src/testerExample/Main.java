package testerExample;

import views.*;
import controllers.*;

public class Main {

	public static void main(String args []) {
		
		LoginView loginView = new LoginView();
		// loads the contact view
		LoginController loginController = new LoginController(loginView);
		
		// set relative position
		loginView.setLocationRelativeTo(null);
		
		loginView.setVisible(true);
		
//		RegisterView rv = new RegisterView();
//		RegisterContoller rc = new RegisterContoller(rv);
//		rv.setVisible(true);
	}
}


